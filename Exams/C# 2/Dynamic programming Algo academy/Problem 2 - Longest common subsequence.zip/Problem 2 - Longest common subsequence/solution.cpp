#include <stdio.h>
#include <string>
using namespace std;
int maxNum(int a, int b) { return a > b ? a : b; }
int main()
{
    // Input
    int N, M;
    scanf("%d", &N);
    scanf("%d", &M);
    string first[N], second[M];
    for(int i = 0; i < N; i++)
    {
        char tmp[102];
        scanf("%s", &tmp);
        first[i] = tmp;
    }
    for(int i = 0; i < M; i++)
    {
        char tmp[102];
        scanf("%s", &tmp);
        second[i] = tmp;
    }

    // Solve
    int solutions[N+1][M+1];
    for(int i = 0; i <= N; i++) solutions[i][0] = 0;
    for(int i = 0; i <= M; i++) solutions[0][i] = 0;
    for(int i = 1; i <= N; i++)
    {
        for(int j = 1; j <= M; j++)
        {
            if (first[i-1] == second[j-1])
            {
                solutions[i][j] = solutions[i-1][j-1] + 1;
            }
            else
            {
                solutions[i][j] = maxNum(solutions[i][j-1], solutions[i-1][j]);
            }
        }
    }

    // Output
    printf("%d\n", solutions[N][M]);

    return 0;
}
