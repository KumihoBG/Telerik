﻿namespace GrandmaToTheMarket
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;

    public class TestGenerator
    {
        private string filePath;
        public const string SmallLetters = "abcdefghijklmnopqrstuvwxyz";
        public const string BigLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        public const int MinNameLength = 4;
        public const int MaxNameLength = 10;
        public const int MinAmmount = 10;
        public const int MaxAmmount = 200;
        public const int MinWeight = 1;
        public const int MaxWeight = 50;
        public const int MinCost = 1;
        public const int MaxCost = 60;
        public const int MaxProductsCount = 100;

        public const string FileNamesFormat = "{0}test.{1}.in.txt";
        private static readonly Random Rand = new Random();

        public void GenerateTests(string filePath = "../../Tests/")
        {
            this.filePath = filePath;
            if (!Directory.Exists(filePath))
            {
                Directory.CreateDirectory(filePath);
            }

            this.CreateTest("001");
            this.CreateTest("002");
            this.CreateTest("003");
            this.CreateTest("004");
            this.CreateTest("005");
            this.CreateTest("006");
            this.CreateTest("007");

            // 0 offers
            this.CreateTest("008", 0);

            // max load
            this.CreateTest("009", MaxProductsCount);
            this.CreateTest("010", MaxProductsCount);
        }

        private void CreateTest(object testNumber, int? prodCount = null)
        {
            int offerCount;
            using (var sw = new StreamWriter(string.Format(FileNamesFormat, this.filePath, testNumber)))
            {
                int ammount =Rand.Next(MinAmmount, MaxAmmount);
                sw.WriteLine(ammount);
                offerCount = prodCount ??  Rand.Next(MaxProductsCount);
                for (int i = 0; i < offerCount; i++)
                {
                    string offer = GenerateOffer(Rand.Next(MinCost, MaxCost), Rand.Next(MinCost, MaxCost));
                    sw.WriteLine(offer);
                }

                sw.WriteLine("END");
            }

            Console.WriteLine("Test {0} is ready! With {1} offers", testNumber, offerCount);
        }

        private string GenerateOffer(int weight, int cost)
        {
            string name = GenerateName(Rand.Next(MinNameLength, MaxNameLength));

            return string.Format("{0} {1} {2}", name, weight, cost);
        }

        private string GenerateName(int length)
        {
            string result = string.Empty;
            for (int i = 0; i < length; i++)
            {
                int index = Rand.Next(SmallLetters.Length);
                result += SmallLetters[index];
            }

            return result;
        }

    }
}
