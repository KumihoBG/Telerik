#include <iostream>
#include <stdio.h>
#include <string>
#include <stdlib.h>

#define MAXN 500
#define MAXC 100

#define max(x, y) x>y?x:y

using namespace std;

int N, C;
int L[MAXN];
int R[MAXN];

int DP[MAXN][MAXC + 1];

long long solve() {

	for (int i = 0; i < N; i++)
	 DP[i][1] = R[i];
	
	for (int c = 2; c <= C; c++)
	 for (int i = 0; i < N; i++) {
	 	DP[i][c] = -1;
	    for (int j = 0; j < N; j++)
	     if (R[i] == L[j])
	      DP[i][c] = max(DP[i][c], DP[j][c - 1]);
	 }
	
	long long result = -1;
	for (int i = 0; i < N; i++)
	 if (DP[i][C] != -1 && (long long)L[i] * DP[i][C] > result)
	  result = (long long)L[i] * DP[i][C];
	return result;
}

int main() {
	cin >> N >> C;
	for (int i = 0; i < N; i++) {
		cin >> L[i] >> R[i];
	}
	cout << solve() << endl;
}
