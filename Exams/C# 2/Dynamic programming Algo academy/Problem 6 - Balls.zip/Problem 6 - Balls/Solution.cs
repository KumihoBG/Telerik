using System;
class Balls
{
    static long TheCount(int L, int N)
    {
        long[,] memo = new long[N + 1, N];
        memo[0, 0] = 1;

        for (int i = 0; i < N; i++)
        {
            //adding ball to an empty cylinder
            memo[i + 1, L - 1] += (4 * memo[i, 0]) % 1000000007;
            memo[i + 1, L - 1] %= 1000000007;

            //adding a different color than the top ball
            for (int j = 1; j <= N - L; j++)
            {
                memo[i + 1, j + L - 1] += (3 * memo[i, j]) % 1000000007;
                memo[i + 1, j + L - 1] %= 1000000007;
            }

            //adding the same color as the top ball
            for (int j = 1; j < N; j++)
            {
                memo[i + 1, j - 1] += memo[i, j];
                memo[i + 1, j - 1]  %= 1000000007;
            }
        }

        return memo[N, 0];
    }

    static void Main()
    {
        int L = int.Parse(Console.ReadLine());
        int N = int.Parse(Console.ReadLine());

        Console.WriteLine(TheCount(L, N));
    }
}
