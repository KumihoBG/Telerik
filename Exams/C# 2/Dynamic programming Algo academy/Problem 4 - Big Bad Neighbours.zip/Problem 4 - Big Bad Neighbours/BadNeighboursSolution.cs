﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BadNeighbours
{
    public class BadNeighboursSolution
    {
        public static int GetMaxDonation(int[] donations, bool isRecursive)
        {
            if (isRecursive)
            {
                return Math.Max(GetMaxDonation(donations, 0, donations.Length - 2, new int[donations.Length]),
                    GetMaxDonation(donations, 1, donations.Length - 1, new int[donations.Length]));
            }
            else
            {
                return Math.Max(GetMaxDonation(donations, 0, donations.Length - 2),
                    GetMaxDonation(donations, 1, donations.Length - 1));
            }
        }

        private static int GetMaxDonation(int[] donations, int start, int end)
        {
            if (donations.Length < 4)
            {
                if (donations.Length == 1)
                {
                    return donations[0];
                }
                else
                {
                    return donations.Max();
                }
            }
            int[] maxDonations = new int[donations.Length];
            maxDonations[start] = donations[start];
            maxDonations[start + 1] = Math.Max(donations[start], donations[start + 1]);

            for (int i = start + 2; i <= end; i++)
            {
                maxDonations[i] = Math.Max(maxDonations[i - 1], maxDonations[i - 2] + donations[i]);
            }
            return maxDonations[end];
        }

        private static int GetMaxDonation(int[] donations, int index, int end, int[] maxDonations)
        {
            if (donations.Length == 1)
            {
                return donations[0];
            }
            if (donations.Length == 2)
            {
                return donations.Max();
            }
            if (index > end)
            {
                return 0;
            }
            if (maxDonations[index] != 0)
            {
                return maxDonations[index];
            }
            maxDonations[index] = Math.Max(
                GetMaxDonation(donations, index + 1, end, maxDonations),
                GetMaxDonation(donations, index + 2, end, maxDonations) + donations[index]);
            return maxDonations[index];
        }

        public static void Solve(bool isRecursive = false)
        {
            int n = int.Parse(Console.ReadLine());
            int[] donations = new int[n];
            for (int i = 0; i < n; i++)
            {
                donations[i] = int.Parse(Console.ReadLine());
            }

            Console.WriteLine(GetMaxDonation(donations, isRecursive));
        }

        static void Main(string[] args)
        {
            Solve(false);
        }
    }
}