#include<iostream>
#include<map>

using namespace std;

#define MAX_N 30000
#define getMax(a,b) a>b?a:b

int n;
int donations[MAX_N + 1];
int maxDonation[MAX_N + 1];

void solve();
int maxNeighbours(int, int);

int main() {

	cin >> n;

	for (int i = 0; i < n; i++){
		cin >> donations[i];
	}

	solve();
	return 0;
}

void solve(){
	int max1 = maxNeighbours(0, n - 2);
	int max2 = maxNeighbours(1, n - 1);

	int max = getMax(max1, max2);

	cout << max << endl;
}

int maxNeighbours(int start, int end){
	if (n < 4)
	{
		int max = donations[0];
		for (int i = 0; i < n; i++)
		{
			if (max < donations[i]){
				max = donations[i];
			}
		}
		return max;
	}

	maxDonation[start] = donations[start];
	maxDonation[start + 1] = getMax(donations[start], donations[start + 1]);

	for (int i = start + 2; i <= end; i++)
	{
		maxDonation[i] = getMax(maxDonation[i - 1], maxDonation[i - 2] + donations[i]);
	}
	return maxDonation[end];
}