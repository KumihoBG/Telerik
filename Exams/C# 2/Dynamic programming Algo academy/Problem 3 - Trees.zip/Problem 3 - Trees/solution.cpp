#include <iostream>
#include <string.h>
#define MAXN 10
using namespace std;
long long memo[MAXN+1][MAXN+1][MAXN+1][MAXN+1][5];
long long solve(int a, int b, int c, int d, int lastType)
{
    if (a + b + c + d == 0) return 1; // base case
    long long count = memo[a][b][c][d][lastType];
    if (count == -1) // Not calculated
    {
        count = 0;
        if (a > 0 && lastType != 0) count += solve(a - 1, b, c, d, 0);
        if (b > 0 && lastType != 1) count += solve(a, b - 1, c, d, 1);
        if (c > 0 && lastType != 2) count += solve(a, b, c - 1, d, 2);
        if (d > 0 && lastType != 3) count += solve(a, b, c, d - 1, 3);
        memo[a][b][c][d][lastType] = count;
    }
    return count;
}
int main()
{
    memset(memo, -1, sizeof(memo));
    int a, b, c, d;
    cin >> a >> b >> c >> d;
    long long answer = solve(a, b, c, d, 4); // 4 is invalid type
    cout << answer << endl;
    return 0;
}
