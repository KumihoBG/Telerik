using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

class Program
{
    static void Main(string[] args) 
    {
        // Console.WriteLine(IsSolutionDynamic("AGCCCGCD", "ACGCGC", "GCGACA"));

        string child = Console.ReadLine();
        int numberOfParents = int.Parse(Console.ReadLine());
        string[] parents = new string[numberOfParents];
        for (int ii = 0; ii < numberOfParents; ++ii)
        {
            parents[ii] = Console.ReadLine();
        }
        for (int ii = 0; ii < parents.Length - 1; ++ii)
        {
            for (int jj = ii; jj < parents.Length; ++jj)
            {
                if (IsSolutionDynamic(child, parents[ii], parents[jj]))
                {
                    Console.WriteLine(ii);
                    Console.WriteLine(jj);
                }
            }
        }
    }
    
    static bool IsSolutionDynamic(
        string target,
        string stringA,
        string stringB)
    {
        bool[,,] isSolution = new bool[target.Length + 1, stringA.Length + 1, stringB.Length + 1];
        for (int ii = 0; ii <= stringA.Length; ++ii)
        for (int jj = 0; jj <= stringB.Length; ++jj)
        {
            isSolution[target.Length, ii, jj] = true;
        }
        
        for (int ii = target.Length - 1; ii >= 0; --ii)
        {
            for (int jj = stringA.Length - 1; jj >= 0; --jj)
            {
                for (int kk = stringB.Length - 1; kk >= 0; --kk)
                {
                    if (stringA[jj] == target[ii] &&
                        (isSolution[ii + 1, jj + 1, kk] ||
                         isSolution[ii + 1, jj + 1, kk + 1]))
                    {
                        isSolution[ii, jj, kk] = true;
                    }
                    if (stringB[kk] == target[ii] &&
                        (isSolution[ii + 1, jj, kk + 1] ||
                         isSolution[ii + 1, jj + 1, kk + 1]))
                    {
                        isSolution[ii, jj, kk] = true;
                    }
                    if (isSolution[ii, jj, kk + 1])
                    {
                        isSolution[ii, jj, kk] = true;
                    }
                    if (isSolution[ii, jj + 1, kk])
                    {
                        isSolution[ii, jj, kk] = true;
                    }
                    if (isSolution[ii, jj + 1, kk + 1])
                    {
                        isSolution[ii, jj, kk] = true;
                    }
                }
            }
        }
        
        for (int ii = 0; ii < stringA.Length; ++ii)
        for (int jj = 0; jj < stringB.Length; ++jj)
        {
            if (isSolution[0, ii, jj])
            {
                return true;
            }
        }
        
        return false;
    }
    
    static bool IsSolutionRecursive(
        string target,
        string stringA, 
        string stringB, 
        int indexTarget = 0,
        int indexA = 0, 
        int indexB = 0)
    {
        if (indexTarget >= target.Length)
        {
            return true;
        }
        if (indexA >= stringA.Length && indexB >= stringB.Length)
        {
            return false;
        }
        if (indexA < stringA.Length && target[indexTarget] == stringA[indexA])
        {
            if (IsSolutionRecursive(target, stringA, stringB, indexTarget + 1, indexA + 1, indexB))
                return true;
            if (IsSolutionRecursive(target, stringA, stringB, indexTarget + 1, indexA + 1, indexB + 1))
                return true;
        }
        if (indexB < stringB.Length && target[indexTarget] == stringB[indexB])
        {
            if (IsSolutionRecursive(target, stringA, stringB, indexTarget + 1, indexA, indexB + 1))
                return true;
            if (IsSolutionRecursive(target, stringA, stringB, indexTarget + 1, indexA + 1, indexB + 1))
                return true;
        }
        if (indexA < stringA.Length && 
            IsSolutionRecursive(target, stringA, stringB, indexTarget, indexA + 1, indexB))
            return true;
        if (indexB < stringB.Length &&
            IsSolutionRecursive(target, stringA, stringB, indexTarget, indexA, indexB + 1))
            return true;
        if (IsSolutionRecursive(target, stringA, stringB, indexTarget, indexA + 1, indexB + 1))
            return true;
        return false;
    }
}
