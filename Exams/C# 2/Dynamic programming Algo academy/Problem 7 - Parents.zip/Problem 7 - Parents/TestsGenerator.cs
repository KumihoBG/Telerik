using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

class Program
{
    static int seed = 2015022211;
    static Random rand;
    const string DNA = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"; // "GATC";
    const int problemCount = 12;
    static void Main(string[] args) 
    {
        for (int ii = 0; ii < problemCount; ++ii)
        {
            if (args.Length > 0)
            {
                seed = int.Parse(args[0]);
            }
             rand = new Random(seed);
            int numberOfPossibleParents = rand.Next(4, 8) + (int)(1.2 * ii);
            int parent1 = rand.Next(0, numberOfPossibleParents);
            int parent2;
            do
            {
                parent2 = rand.Next(0, numberOfPossibleParents);
            }
            while (parent1 == parent2);
            
            int length = 10 + ii * 2;
            string prefix = "test." + string.Format("{0:000}", ii < 2 ? ii + 100 : ii - 1);
            string input = prefix + ".in";
            string output = prefix + ".out";
            
            string[] possibleParents = Enumerable.Range(0, numberOfPossibleParents).Select(_ => GetDNAString(length)).ToArray();
            string child = MergeDNAs(possibleParents[parent1], possibleParents[parent2]);
            using(var sw = new StreamWriter(input))
            {
                sw.WriteLine(child);
                sw.WriteLine(numberOfPossibleParents);
                foreach (string possibleParent in possibleParents)
                {
                    sw.WriteLine(possibleParent);
                }
            }
            
            using (var sw = new StreamWriter(output))
            {
                sw.WriteLine(Math.Min(parent1, parent2));
                sw.WriteLine(Math.Max(parent1, parent2));
            }
        }
    }
    
    static string MergeDNAs(string parent1, string parent2)
    {
        while (true)
        {
            var sb = new StringBuilder(parent1.Length);
            int inParent1 = 0;
            int inParent2 = 0;
            while (sb.Length < parent1.Length &&
                inParent1 < parent1.Length &&
                inParent2 < parent2.Length)
            {
    //             bool mutation = rand.Next() % 8 == 0;
    //             if (mutation)
    //             {
    //                 sb.Append(DNA[rand.Next(DNA.Length)]);
    //             }
    //             else
                bool includeParent1 = rand.Next() % 2 == 1;
                bool includeParent2 = rand.Next() % 2 == 1;
                bool advanceParent1 = includeParent1 || rand.Next() % 2 == 1;
                bool advanceParent2 = includeParent2 || rand.Next() % 2 == 1;
                bool parent1First = rand.Next() % 2 == 1;
                
                if (includeParent1 && includeParent2)
                {
                    if (parent1First)
                    {
                        sb.Append(parent1[inParent1]);
                        sb.Append(parent2[inParent2]);
                    }
                    else
                    {
                        sb.Append(parent2[inParent2]);
                        sb.Append(parent1[inParent1]);
                    }
                }
                else if (includeParent1)
                {
                    sb.Append(parent1[inParent1]);
                }
                else if (includeParent2)
                {
                    sb.Append(parent2[inParent2]);
                }
                if (advanceParent1)
                {
                    inParent1 += 1;
                }
                if (advanceParent2)
                {
                    inParent2 += 1;
                }
            }
            if (sb.Length >= parent1.Length)
            {
                return sb.ToString().Substring(0, parent1.Length);
            }
        }
    }
    
    static string GetDNAString(int length)
    {
        var sb = new StringBuilder(length);
        for (int ii = 0; ii < length; ++ii)
        {
            sb.Append(DNA[rand.Next(DNA.Length)]);
        }
        return sb.ToString();
    }
}
