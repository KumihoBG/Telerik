#include<iostream>
#include<string>
#include<algorithm>
using namespace std;

short A[256][256];
short B[256][256];
int main()
{
	string a,b,c,d;
	cin>>a>>b>>c;

	for(unsigned i=0; i<a.size(); ++i)
		for(unsigned j=0; j<b.size(); ++j)
		{
			if(a[i] == b[j])
				A[i+1][j+1] = A[i][j]+1;
			else if(A[i+1][j] > A[i][j+1])
				A[i+1][j+1] = A[i+1][j];
			else A[i+1][j+1] = A[i][j+1];
		}

	for(unsigned i=a.size(), j=b.size(); i>0 && j>0;)
	{
		if(a[i-1]==b[j-1])
		{
			d.push_back(a[i-1]);
			--i; --j;
		}
		else if(A[i][j-1] > A[i-1][j])
			--j;
		else --i;
	}
	std::reverse(d.begin(), d.end());

	for(unsigned i=0; i<c.size(); ++i)
		for(unsigned j=0; j<d.size(); ++j)
		{
			if(c[i] == d[j])
				B[i+1][j+1] = B[i][j]+1;
			else if(B[i+1][j] > B[i][j+1])
				B[i+1][j+1] = B[i+1][j];
			else B[i+1][j+1] = B[i][j+1];
		}

	std::cout<<B[c.size()][d.size()]<<'\n';
}
