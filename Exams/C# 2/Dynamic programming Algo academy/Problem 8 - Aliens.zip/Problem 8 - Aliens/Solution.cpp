#include<iostream>
#include<string>
using namespace std;

short A[256][256][256];
int main()
{
	string a,b,c;
	cin>>a>>b>>c;
	for(unsigned i=0; i<a.size(); ++i)
		for(unsigned j=0; j<b.size(); ++j)
			for(unsigned k=0; k<c.size(); ++k)
			{
				if(a[i]==b[j] && a[i]==c[k])
					A[i+1][j+1][k+1] = A[i][j][k]+1;
				else if(A[i][j+1][k+1] > A[i+1][j][k+1] && A[i][j+1][k+1] > A[i+1][j+1][k])
					A[i+1][j+1][k+1] = A[i][j+1][k+1];
				else if(A[i+1][j][k+1] > A[i+1][j+1][k])
					A[i+1][j+1][k+1] = A[i+1][j][k+1];
				else A[i+1][j+1][k+1] = A[i+1][j+1][k];
			}

	std::cout<<A[a.size()][b.size()][c.size()]<<'\n';
}
